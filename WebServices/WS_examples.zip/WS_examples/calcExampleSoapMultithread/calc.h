//gsoap calcns service name: calculator
//gsoap calcns service style: rpc
//gsoap calcns service location: http//localhost:10000
//gsoap calcns service encoding: encoded
//gsoap calcns service namespace: urn:calcExample
int calcns__add  (int a, int b, int *res);
int calcns__subs (int a, int b, int *res);
int calcns__mult  (int a, int b, int *res);
int calcns__div (int a, int b, int *res);

